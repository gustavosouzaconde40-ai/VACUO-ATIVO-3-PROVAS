# VACUO-ATIVO-3-PROVAS
## Aeternvm Vacuvm — Ciclo de Comprovação

**Estado (2026)**  
Ciclo metodológico: **FECHADO**  
Ciclo de comprovação: **ABERTO**

Teoria: EFT Lorentz-invariante com parâmetros falsificáveis \(M\), \(\xi\), \(c_0\), \(c_1\).  
Escalas: \(10^{-6}\) m (Galileu) → \(10^{23}\) m (COSMOS-Web).

---

## 5 Pilares

### 1. JWST/COSMOS-Web + DESI \(f_b\)
- Scripts: `AV_DESI_Y3_sim.py`, `AV_DESI_fb.py`
- Hoje: \(\Delta\chi^2 \approx 0.9\), \(\xi \in [-0.37, 0.13]\) (95 % CL)
- Meta comprovação: \(\Delta\chi^2 > 9\) com dados reais DESI Y3 + tSZ (erro \(\lesssim 0.015\))

### 2. Magnetar 1E 1547.0-5408 (IXPE)
- Script: `AV_likelihood.py`
- Hoje: \(M \gtrsim 1\) TeV para \(|c_0-c_1|=3\), \(\Delta\chi^2 \approx 0\)
- Meta: \(Q(\phi)\), \(U(\phi)\) fase-resolvidos + \(\Delta\chi^2 > 9\)

### 3. LUX-ZEPLIN 248 keV
- Apenas limite: \(M_1 \gtrsim 10^{18}\) GeV, \(m_\chi \gtrsim 10^{-6}\) eV
- **Não usar como evidência**

### 4. Galileu Rb-87 → nanodiamante \(10^8\) amu
- Hoje: \(\Gamma T < 0.05\) (preserva coerência)
- Meta: perda de contraste em massa escalada = saturação \(\chi_{\rm sat}\)

### 5. Z0-Probe (NOVO) — Medição direta de \(Z_0\) vs \(B\)
- Scripts: `AV_Z0_Probe_Experiment.pdf`, `AV_Z0_Probe_sensitivity.py`
- Aparato: cavidade Al 6061 \(Q\sim 5\times 10^4\), \(B\) até 3 T, VIEC-FEMP
- Sensibilidade Al 6061: \(3\times 10^{-6}\) relativa em \(Z\)
- Previsão AV para \(M=1\) TeV, \(B=3\) T: \(\Delta Z/Z_0 \sim 10^{-43}\) (37 ordens abaixo)
- Limite real com \(3\times 10^{-6}\): \(M \gtrsim\) keV (já excluído pelo magnetar)

**Conclusão honesta do Z0-Probe**  
Não compete em \(M\) com o magnetar. Compete em **ontologia**: é o único experimento que mede \(Z_0\) diretamente como quantidade física versus \(B\).  
- Se medir variação \(> 3\times 10^{-6}\) com padrão \(B^2\) e \(\Delta\chi^2>9\): nova física em baixa energia (revolucionário, mas em tensão com astrofísica).  
- Se medir nulo a \(3\times 10^{-6}\): primeira medição direta da constância de \(Z_0\) vs \(B\) — resultado de metrologia publicável.

---

## Arquivos do repositório

| Arquivo | Função |
|---------|--------|
| `AV_likelihood.py` | Magnetar IXPE + limite Galileu |
| `AV_DESI_Y3_sim.py` | Likelihood \(f_b\) estilo DESI Y3 |
| `AV_Z0_Probe_sensitivity.py` | Sensibilidade e limite do Z0-Probe |
| `AV_Z0_Probe_Experiment.pdf` | Protocolo experimental completo |
| `aeternvm_haloscope_DESI.pdf` | DESI + VIEC-FEMP |
| `Z0_Probe_real.png` | Previsão vs sensibilidade |
| `DESI_Y3_fb_filament_test.png` | Ajuste \(f_b\) |
| `README.md` | Este arquivo |

---

## Roteiro 8 meses (Z0-Probe)

1. Meses 1–2: projeto mecânico da cavidade + integração FEMP  
2. Meses 3–4: calibração zero-campo + estabilidade 10 mK  
3. Meses 5–6: campanha \(0\to 1.5\) T  
4. Meses 7–8: campanha até 3 T + análise + publicação do limite de constância \(3\times 10^{-6}\)

---

**DOI:** 10.5281/zenodo.22255253  
**Licença:** CC-BY 4.0  
**Autor:** Gustavo Alves Condé — ORCID 0009-0003-8264-7907
