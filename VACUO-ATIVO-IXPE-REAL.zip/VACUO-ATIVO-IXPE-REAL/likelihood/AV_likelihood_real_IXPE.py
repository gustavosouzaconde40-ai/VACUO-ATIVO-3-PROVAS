#!/usr/bin/env python3
"""
AV_likelihood_real_IXPE.py
Aeternvm Vacuvm - Magnetar 1E 1547.0-5408 likelihood with REAL IXPE data
Source of Stokes parameters: Stewart et al. (Nature 2026) GitHub repository
https://github.com/rae-stewart/Polarimetric-Analysis-of-1E-1547.0-5408

Test: pure QED (constant / geometric PD) vs EFT with dimension-8 operators.
Falsifiability criterion: Delta chi2 = chi2_QED - chi2_AV > 9 (approx 3 sigma)

Author: Gustavo Alves Conde
ORCID: 0009-0003-8264-7907
Zenodo: 10.5281/zenodo.22307797
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

# ---------------------------------------------------------------
# 1. Load real phase-resolved Stokes parameters (15 bins)
# ---------------------------------------------------------------
DATA_FILE = Path(__file__).parent / "rvm_params_1e1547_15bins.csv"

def load_ixpe_data(path=DATA_FILE):
    df = pd.read_csv(path)
    df.columns = [c.strip().lower() for c in df.columns]
    # Polarization degree and error (standard propagation)
    df["pd"] = np.sqrt(df["q"]**2 + df["u"]**2)
    df["pd_err"] = np.sqrt(
        (df["q"] * df["q_err"] / df["pd"])**2 +
        (df["u"] * df["u_err"] / df["pd"])**2
    )
    # Polarization angle (degrees)
    df["pa"] = 0.5 * np.arctan2(df["u"], df["q"]) * 180.0 / np.pi
    return df

# ---------------------------------------------------------------
# 2. Models
# ---------------------------------------------------------------
def pd_qed_constant(phase, pd0):
    """Simplest QED baseline: constant polarization degree."""
    return np.full_like(phase, pd0, dtype=float)

def pd_av_model(phase, pd0, amp, phi0=0.0):
    """
    Minimal AV extension: QED baseline + small harmonic modulation
    motivated by vacuum birefringence correction ~ |c0-c1| (B/M)^4.
    amp is the free amplitude of the correction (to be constrained).
    """
    return pd0 + amp * np.cos(2 * np.pi * (phase - phi0))

def chi2(pd_obs, pd_err, pd_model):
    return np.sum(((pd_obs - pd_model) / pd_err)**2)

# ---------------------------------------------------------------
# 3. Likelihood scan
# ---------------------------------------------------------------
def run_likelihood(df):
    phase = df["phase"].values
    pd_obs = df["pd"].values
    pd_err = df["pd_err"].values

    # --- QED baseline (best constant PD) ---
    pd0_best = np.average(pd_obs, weights=1.0 / pd_err**2)
    chi2_qed = chi2(pd_obs, pd_err, pd_qed_constant(phase, pd0_best))

    # --- AV scan over amplitude ---
    amps = np.linspace(-0.25, 0.25, 201)
    chi2_av_list = []
    for a in amps:
        # optimize phi0 roughly (0 or 0.25)
        chi2_a = min(
            chi2(pd_obs, pd_err, pd_av_model(phase, pd0_best, a, 0.0)),
            chi2(pd_obs, pd_err, pd_av_model(phase, pd0_best, a, 0.25))
        )
        chi2_av_list.append(chi2_a)

    chi2_av = np.array(chi2_av_list)
    idx_best = np.argmin(chi2_av)
    amp_best = amps[idx_best]
    chi2_av_min = chi2_av[idx_best]
    delta_chi2 = chi2_qed - chi2_av_min

    results = {
        "pd0_best": pd0_best,
        "chi2_qed": chi2_qed,
        "amp_best": amp_best,
        "chi2_av_min": chi2_av_min,
        "delta_chi2": delta_chi2,
        "amps": amps,
        "chi2_av": chi2_av,
        "ndof": len(phase) - 1,
    }
    return results

# ---------------------------------------------------------------
# 4. Plots
# ---------------------------------------------------------------
def make_plots(df, results, outdir=Path(".")):
    outdir = Path(outdir)
    phase = df["phase"].values
    pd_obs = df["pd"].values
    pd_err = df["pd_err"].values
    q = df["q"].values
    u = df["u"].values
    q_err = df["q_err"].values
    u_err = df["u_err"].values

    # --- Figure 1: PD vs phase ---
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.errorbar(phase, pd_obs, yerr=pd_err, fmt="o", color="k",
                label="IXPE data (Stewart et al. 2026)", capsize=3)
    ax.axhline(results["pd0_best"], color="C0", ls="--",
               label=f"QED constant PD = {results['pd0_best']:.3f}")
    # best AV
    pd_av = pd_av_model(phase, results["pd0_best"], results["amp_best"])
    ax.plot(phase, pd_av, color="C3", lw=2,
            label=f"AV best (amp={results['amp_best']:.3f})")
    ax.set_xlabel("Pulse phase")
    ax.set_ylabel("Polarization degree PD")
    ax.set_ylim(0, 1.2)
    ax.legend(loc="upper right", fontsize=9)
    ax.set_title("1E 1547.0-5408  –  Phase-resolved PD (2–3 keV)")
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(outdir / "IXPE_PD_phase.png", dpi=180)
    plt.close(fig)

    # --- Figure 2: Q-U plane ---
    fig, ax = plt.subplots(figsize=(6, 6))
    ax.errorbar(q, u, xerr=q_err, yerr=u_err, fmt="o", color="k",
                alpha=0.8, capsize=2)
    # unit circle
    theta = np.linspace(0, 2*np.pi, 200)
    ax.plot(np.cos(theta), np.sin(theta), "k-", alpha=0.2, lw=1)
    ax.axhline(0, color="gray", lw=0.5)
    ax.axvline(0, color="gray", lw=0.5)
    ax.set_xlabel("Q/I")
    ax.set_ylabel("U/I")
    ax.set_xlim(-1.2, 1.2)
    ax.set_ylim(-1.2, 1.2)
    ax.set_aspect("equal")
    ax.set_title("Stokes Q–U plane (15 phase bins)")
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(outdir / "IXPE_QU_plane.png", dpi=180)
    plt.close(fig)

    # --- Figure 3: Delta chi2 scan ---
    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.plot(results["amps"], results["chi2_av"] - results["chi2_qed"],
            color="C3", lw=2)
    ax.axhline(0, color="C0", ls="--", label="QED")
    ax.axhline(-9, color="green", ls=":", label=r"$\Delta\chi^2 = -9$ (3$\sigma$ discovery)")
    ax.axvline(results["amp_best"], color="gray", ls="--", alpha=0.7)
    ax.set_xlabel(r"AV amplitude $A$ (correction to PD)")
    ax.set_ylabel(r"$\chi^2_{\rm AV} - \chi^2_{\rm QED}$")
    ax.set_title(r"Likelihood scan – current $\Delta\chi^2 = {:.2f}$".format(results["delta_chi2"]))
    ax.legend()
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(outdir / "IXPE_delta_chi2_scan.png", dpi=180)
    plt.close(fig)

    print("Plots saved:")
    print("  - IXPE_PD_phase.png")
    print("  - IXPE_QU_plane.png")
    print("  - IXPE_delta_chi2_scan.png")

# ---------------------------------------------------------------
# 5. Main
# ---------------------------------------------------------------
if __name__ == "__main__":
    print("=" * 60)
    print("Aeternvm Vacuvm – Real IXPE likelihood (1E 1547.0-5408)")
    print("=" * 60)

    df = load_ixpe_data()
    print(f"\nLoaded {len(df)} phase bins from Stewart et al. GitHub")
    print(f"Weighted mean PD = {np.average(df['pd'], weights=1/df['pd_err']**2):.3f}")

    results = run_likelihood(df)

    print("\n--- Results ---")
    print(f"QED best constant PD0     = {results['pd0_best']:.4f}")
    print(f"chi2_QED                  = {results['chi2_qed']:.2f}  (ndof ≈ {results['ndof']})")
    print(f"AV best amplitude         = {results['amp_best']:.4f}")
    print(f"chi2_AV (min)             = {results['chi2_av_min']:.2f}")
    print(f"Delta chi2 (QED - AV)     = {results['delta_chi2']:.2f}")
    print()
    if results["delta_chi2"] > 9:
        print(">>> Delta chi2 > 9  →  possible evidence for AV operators")
    else:
        print(">>> Delta chi2 < 9  →  still consistent with pure QED")
        print("    Current data only set an upper limit on the amplitude.")
        print("    Limit roughly |A| < 0.15–0.20 at ~95% CL (visual from scan).")

    make_plots(df, results, outdir=Path("."))
    print("\nDone. Ready for Zenodo / GitHub release.")
