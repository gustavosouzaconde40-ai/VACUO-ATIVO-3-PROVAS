#!/usr/bin/env python3
"""
AV_Z0_Probe_sensitivity.py
Aeternvm Vacuvm - Z0-Probe: medição direta de Z_eff vs B

Física (unidades naturais hbar = c = 1):
  1 T = 195.35 eV²
  M em eV
  Delta Z / Z0 ≈ 0.5 * |α1 - α0| * (B² / M⁴)

Sensibilidade-alvo Al 6061 (Q ~ 5e4, 10 mK): 3e-6 relativa
"""

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

Z0 = 376.730313668  # Ohm
B_c_T = 4.4e9       # campo crítico QED (Tesla)

def delta_Z_over_Z0(B_T, M_TeV, dc=1.0):
    """
    B_T : campo em Tesla
    M_TeV : escala em TeV
    dc = |α1 - α0| ~ O(1)
    Retorna |Delta Z / Z0|
    """
    M_eV = M_TeV * 1e12
    B_eV2 = 195.35 * B_T
    return dc * 0.5 * (B_eV2 ** 2) / (M_eV ** 4)

# ---------- Curvas ----------
B_vals = np.linspace(0.05, 3.0, 120)
Ms = [1e-6, 0.001, 1.0, 1000.0]  # TeV
colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728']

fig, ax = plt.subplots(figsize=(8, 5))
for M, c in zip(Ms, colors):
    dz = [delta_Z_over_Z0(B, M) for B in B_vals]
    ax.semilogy(B_vals, dz, color=c, lw=1.8, label=f'M = {M:g} TeV')

# Sensibilidades
ax.axhline(3e-6, color='#e377c2', ls='--', lw=1.6, label='Sens Al 6061 3e-6')
ax.axhline(1e-12, color='#bcbd22', ls='--', lw=1.6, label='Sens futuro SC 1e-12')

ax.set_xlabel(r'$B$ [T]')
ax.set_ylabel(r'$|\Delta Z / Z_0|$')
ax.set_title('Z0-Probe: previsão AV vs sensibilidade real')
ax.legend(fontsize=8, loc='upper right')
ax.grid(True, which='both', alpha=0.3)
ax.set_ylim(1e-50, 1e-5)
plt.tight_layout()
plt.savefig('/home/workdir/artifacts/Z0_Probe_real.png', dpi=220)
print('Figura salva: Z0_Probe_real.png')

# ---------- Limite em M ----------
def M_limit(sens, B_T=3.0, dc=1.0):
    """M_lim em TeV para dado sens e B"""
    B_eV2 = 195.35 * B_T
    M_eV4 = dc * 0.5 * (B_eV2 ** 2) / sens
    M_eV = M_eV4 ** 0.25
    return M_eV / 1e12

print('\n=== Limites em M (B = 3 T) ===')
for sens in [3e-6, 1e-7, 1e-9, 1e-12]:
    Ml = M_limit(sens, 3.0, dc=1.0)
    print(f'Sens {sens:.0e} → M_lim ≈ {Ml*1000:.2f} GeV = {Ml:.4f} TeV')
    print(f'  (exclui M < {Ml*1000:.1f} GeV se nulo)')

print('\nConclusão:')
print('  Al 6061 (3e-6): limite ~ 0.5 keV — já excluído pelo magnetar (M ≳ 1 TeV).')
print('  Z0-Probe não compete em M. Compete em ontologia: mede Z0 diretamente.')
print('  Resultado publicável: constância de Z0 a 3e-6 vs B até 3 T.')
print('  Para TeV: precisa cavidade SC Q~1e10 + SQUID (sens ~1e-12) + ainda longe.')
