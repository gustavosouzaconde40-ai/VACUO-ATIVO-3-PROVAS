#!/usr/bin/env python3
"""
Aeternvm Vacuvm - Pilar 1: Simulação DESI Y3 + tSZ realista
Teste: f_b em filamentos WHIM — ΛCDM vs AV (ξ χ² R)
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# ---------- Dados simulados estilo DESI Y3 + ACT/Planck tSZ stacking ----------
# Baseados em tendências de de Vries et al. e projeções DESI Y3
# delta = overdensity, fb = M_b/M_tot, erro típico de stacking

filament_overdensity = np.array([2.0, 4.0, 8.0, 15.0, 30.0, 50.0])
# Observado: tendência de aumento de fb com densidade (menos feedback em núcleos densos)
fb_obs = np.array([0.055, 0.078, 0.105, 0.132, 0.155, 0.168])
fb_err = np.array([0.025, 0.022, 0.028, 0.032, 0.038, 0.045])

def fb_LCDM(delta):
    """ΛCDM + hydro (TNG/EAGLE-like): feedback expulsa bárions em baixa densidade"""
    fb_cosmic = 0.157
    return fb_cosmic * (1.0 - 0.42 * np.exp(-delta / 12.0))

def fb_AV(delta, xi, Z0=376.73):
    """AV: termo extra ξ <χ²> R / ρ_c — saturação retém bárions"""
    fb_base = fb_LCDM(delta)
    # termo de saturação proporcional a sqrt(delta) (aproximação de curvatura local)
    term = xi * 0.085 * np.sqrt(delta / 10.0)
    return fb_base + term

def chi2(fb_model):
    return np.sum(((fb_obs - fb_model) / fb_err)**2)

chi2_lcdm = chi2(fb_LCDM(filament_overdensity))
print("=== DESI Y3 SIMULADO (tSZ stacking style) ===")
print(f"chi2_LCDM = {chi2_lcdm:.3f}")

# Scan xi
xis = np.linspace(-1.5, 1.5, 301)
chi2s = np.array([chi2(fb_AV(filament_overdensity, xi)) for xi in xis])
best_idx = np.argmin(chi2s)
xi_best = xis[best_idx]
chi2_best = chi2s[best_idx]
delta_chi2 = chi2_lcdm - chi2_best

print(f"Melhor xi = {xi_best:.3f}")
print(f"chi2_AV (melhor) = {chi2_best:.3f}")
print(f"Delta chi2 = chi2_LCDM - chi2_AV = {delta_chi2:.3f}")

# Limite 95% (Delta chi2 = 3.84 para 1 parâmetro)
mask = chi2s < (chi2_best + 3.84)
xi_lo = xis[mask].min() if mask.any() else xis[0]
xi_hi = xis[mask].max() if mask.any() else xis[-1]
print(f"Limite 95% CL: xi in [{xi_lo:.3f}, {xi_hi:.3f}]")
print(f"Para comprovação precisa Delta chi2 > 9. Atual = {delta_chi2:.3f} -> ainda limite.")

# Plots
fig, axes = plt.subplots(1, 2, figsize=(11, 4.2))

ax = axes[0]
ax.errorbar(filament_overdensity, fb_obs, yerr=fb_err, fmt='ko', label='DESI Y3 sim (tSZ)', capsize=3)
delta_fine = np.linspace(1.5, 55, 200)
ax.plot(delta_fine, fb_LCDM(delta_fine), 'b-', lw=2, label='ΛCDM + hydro')
ax.plot(delta_fine, fb_AV(delta_fine, xi_best), 'r--', lw=2, label=f'AV (ξ={xi_best:.2f})')
ax.set_xlabel(r'Overdensity $\delta$')
ax.set_ylabel(r'$f_b = M_b / M_{\rm tot}$')
ax.set_title('Fração bariônica em filamentos WHIM')
ax.legend(fontsize=8)
ax.grid(alpha=0.3)

ax = axes[1]
ax.plot(xis, chi2s - chi2_lcdm, 'b-', lw=1.5)
ax.axhline(0, color='k', ls='-', lw=0.8)
ax.axhline(-3.84, color='red', ls='--', label='95% melhor que ΛCDM')
ax.axhline(-9.0, color='darkred', ls='--', label='3σ evidência')
ax.set_xlabel(r'$\xi$ (acoplamento não-mínimo)')
ax.set_ylabel(r'$\Delta\chi^2 = \chi^2_{\rm AV} - \chi^2_{\Lambda{\rm CDM}}$')
ax.set_title(r'$\Delta\chi^2$ vs $\xi$')
ax.legend(fontsize=8)
ax.grid(alpha=0.3)
ax.set_ylim(-12, 15)

plt.tight_layout()
plt.savefig('/home/workdir/artifacts/DESI_Y3_fb_filament_test.png', dpi=220)
print("\nPlot salvo: DESI_Y3_fb_filament_test.png")
print("Conclusão: com erros atuais, AV e ΛCDM são indistinguíveis. Precisa de erros ~0.015 e tendência real.")
