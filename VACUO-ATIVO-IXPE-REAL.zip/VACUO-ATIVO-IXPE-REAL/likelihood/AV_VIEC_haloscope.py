#!/usr/bin/env python3
"""
Aeternvm Vacuvm - Exploração do Haloscópio VIEC-FEMP
Hardware Fibonacci temporal → sonda de Z-Bits / axion-like (μeV)
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

print("=== HALOSCÓPIO VIEC-Mk.IV-C-FEMP-V1 ===\n")

# Parâmetros de hardware (do preprint)
tau_base_ns = 1.0          # unidade de tempo fundamental (ajustável)
slots_tau = np.array([3, 8, 13])  # Fibonacci
slot_mm = slots_tau * 20.0  # 60, 160, 260 mm se tau→20 mm (escala RF)
Z0_line = 50.0             # Ohm
S11_target = -20.0         # dB
crouzeix_jin = 2.0

print(f"Slots Fibonacci: {slots_tau} τ → {slot_mm} mm (escala RF exemplo)")
print(f"Linha: {Z0_line} Ω Al 6061 | S11 < {S11_target} dB | Crouzeix-Jin ||p(A)|| ≤ {crouzeix_jin}")

# Frequências de ressonância aproximadas (quasicristal temporal)
# f_n ~ c / (2 * L_n) para cavidade aberta, corrigido por fator Fibonacci
c = 3e8  # m/s
L = slot_mm * 1e-3
f_res = c / (2 * L) / 1e9  # GHz
print(f"\nFrequências de ressonância nominais (GHz): {f_res}")

# Para axion-like / Z-Bit: m c² = h f → m [μeV] ≈ 4.14 * f[GHz]
m_ueV = 4.135667662 * f_res
print(f"Massa equivalente (μeV): {m_ueV}")

# Sensibilidade de haloscópio (ordem de grandeza)
# SNR ~ (g² B² V Q / m) * sqrt(t) / T_sys  (simplificado)
# Aqui apenas demonstramos a janela de massa acessível

print("\n--- Janela de massa acessível ---")
print("Ajustando τ (escala geométrica) de 5 mm a 200 mm:")
tau_mm = np.array([5, 10, 20, 50, 100, 200])
for t in tau_mm:
    L = slots_tau * t * 1e-3
    f = c / (2 * L) / 1e9
    m = 4.136 * f
    print(f"  τ={t:3d} mm → f≈{f[0]:.2f}–{f[-1]:.2f} GHz → m≈{m[0]:.1f}–{m[-1]:.1f} μeV")

print("\n--- Condição para se tornar sonda cosmológica ---")
print("O FEMP só deixa de ser 'engenharia de RF' e vira sonda se:")
print("  1. τ sintonizado a 1/m_χ (Compton)")
print("  2. SNR > 5 em ressonância acima do fundo Johnson-Nyquist")
print("  3. Excesso de potência correlacionado com B externo ou saturação local")
print("Até lá: hardware válido de quasicristal temporal (Dumitrescu 2022), não detecção.")

# Plot esquemático
fig, ax = plt.subplots(figsize=(7.5, 4))
tau_range = np.linspace(5, 250, 100)
L3 = 3 * tau_range * 1e-3
L8 = 8 * tau_range * 1e-3
L13 = 13 * tau_range * 1e-3
f3 = c / (2 * L3) / 1e9
f8 = c / (2 * L8) / 1e9
f13 = c / (2 * L13) / 1e9
m3 = 4.136 * f3
m8 = 4.136 * f8
m13 = 4.136 * f13

ax.plot(tau_range, m3, label='slot 3τ', lw=1.8)
ax.plot(tau_range, m8, label='slot 8τ', lw=1.8)
ax.plot(tau_range, m13, label='slot 13τ', lw=1.8)
ax.axhspan(1, 50, alpha=0.12, color='green', label='janela típica axion-like')
ax.set_xlabel(r'$\tau$ [mm] (escala geométrica do FEMP)')
ax.set_ylabel(r'massa equivalente [$\mu$eV]')
ax.set_yscale('log')
ax.set_title('VIEC-FEMP como Haloscópio: Janela de Massa vs Escala')
ax.legend(fontsize=8)
ax.grid(alpha=0.3)
plt.tight_layout()
plt.savefig('/home/workdir/artifacts/VIEC_FEMP_haloscope_window.png', dpi=220)
print("\nPlot salvo: VIEC_FEMP_haloscope_window.png")
print("Conclusão: o hardware já existe; falta sintonizar τ e medir SNR em ressonância.")
