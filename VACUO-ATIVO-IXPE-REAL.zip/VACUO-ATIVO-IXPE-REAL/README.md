# VACUO-ATIVO – Real IXPE Likelihood Package

**Aeternvm Vacuvm Research Program**  
Author: Gustavo Alves Condé  
ORCID: [0009-0003-8264-7907](https://orcid.org/0009-0003-8264-7907)  
Zenodo concept: [10.5281/zenodo.22307797](https://doi.org/10.5281/zenodo.22307797)

---

## Status of the proof cycle (2026-09-04)

| Pillar | Data source | Δχ² (baseline − AV) | Result |
|--------|-------------|---------------------|--------|
| **Magnetar 1E 1547.0-5408** | Stewart et al. Nature 2026 (15 phase bins) | **6.46** | Consistent with pure QED. Limit only. |
| DESI filament \(f_b(\delta)\) | mocks | ~0.9 | Limit only |
| Z0-Probe (lab RF) | not yet executed | — | Metrology target \(3\times10^{-6}\) |
| Galileu / nanodiamond | scaled limit | — | \(m_\chi \gtrsim 10^{-6}\) eV |
| LUX-ZEPLIN | single event | — | Reclassified as limit |

**Falsifiability criterion adopted throughout:** \(\Delta\chi^2 > 9\) (≈ 3σ).

**Current conclusion**  
Methodological cycle (EFT + public likelihoods + code): **closed**.  
Proof cycle: **still open**. No pillar has yet produced \(\Delta\chi^2 > 9\).

---

## Package contents

```
VACUO-ATIVO-IXPE-REAL/
├── README.md                          ← this file
├── data/
│   └── rvm_params_1e1547_15bins.csv   ← real Stokes Q/I, U/I (Stewart et al.)
├── likelihood/
│   ├── AV_likelihood_real_IXPE.py     ← main magnetar likelihood (REAL data)
│   ├── AV_DESI_Y3_sim.py
│   ├── AV_VIEC_haloscope.py
│   └── AV_Z0_Probe_sensitivity.py
├── figures/
│   ├── IXPE_PD_phase.png
│   ├── IXPE_QU_plane.png
│   ├── IXPE_delta_chi2_scan.png
│   ├── DESI_Y3_fb_filament_test.png
│   ├── VIEC_FEMP_haloscope_window.png
│   └── Z0_Probe_real.png
├── docs/
│   ├── README_IXPE_likelihood.md
│   ├── AV_Final_5_Pilares.pdf
│   ├── AV_Z0_Probe_Experiment.pdf
│   └── aeternvm_4pilares_comprovacao.pdf
└── joss/
    └── JOSS_Vacuum_Depletion_section_revised.md  ← honest wording for JOSS
```

---

## Quick start – magnetar test

```bash
cd likelihood
python AV_likelihood_real_IXPE.py
```

Expected output (current data):

```
chi2_QED          = 18.12
chi2_AV (min)     = 11.66
Delta chi2        = 6.46   → still consistent with pure QED
```

---

## Data provenance

Phase-resolved Stokes parameters of 1E 1547.0-5408 come from the public GitHub repository released by the authors of the Nature paper:

- Stewart et al., Nature 656, 590–594 (2026)
- https://github.com/rae-stewart/Polarimetric-Analysis-of-1E-1547.0-5408

No proprietary or embargoed data are used.

---

## Honest statement on \(Z_0\)

The analytical link between the vacuum impedance \(Z_0 \approx 376.73\,\Omega\) and the dark-energy scale \(V_0\) is a **motivational hypothesis**, not an experimental or first-principles proof. See the revised text in `joss/JOSS_Vacuum_Depletion_section_revised.md`.

---

## License

MIT (code)  
CC-BY-4.0 (documentation and figures, unless otherwise noted)

## Citation

If you use this package please cite:

- Condé, G. A. (2026). Aeternvm Vacuvm – Real IXPE Likelihood Package. Zenodo. https://doi.org/10.5281/zenodo.22307797
- Stewart et al. (2026) for the original IXPE Stokes parameters.
