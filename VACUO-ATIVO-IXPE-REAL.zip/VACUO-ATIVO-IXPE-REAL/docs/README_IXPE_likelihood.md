# Real IXPE Likelihood – 1E 1547.0-5408

**Status of the proof cycle (2026-09-04)**

| Test | Data | Δχ² (QED − AV) | Interpretation |
|------|------|----------------|----------------|
| Magnetar PD (15 phase bins) | Stewart et al. GitHub (Nature 2026) | **6.46** | Still consistent with pure QED. Limit only. |
| DESI fb(δ) filaments | mocks | ~0.9 | Limit only |
| Z0-Probe (lab) | not yet run | — | Metrology target 3×10⁻⁶ |

**Falsifiability criterion adopted:** Δχ² > 9 ≈ 3σ evidence.

Current real magnetar data give Δχ² = 6.46 < 9 → the Aeternvm Vacuvm dimension-8 operators remain allowed but are **not preferred**. The result is an upper bound on the correction amplitude |A| ≲ 0.15–0.20.

## Files

- `AV_likelihood_real_IXPE.py` – full likelihood with real Stokes parameters
- `rvm_params_1e1547_15bins.csv` – 15-bin Q/I, U/I from Stewart et al.
- `IXPE_PD_phase.png` – PD vs pulse phase
- `IXPE_QU_plane.png` – Stokes Q–U plane
- `IXPE_delta_chi2_scan.png` – likelihood scan over AV amplitude

## How to reproduce

```bash
python AV_likelihood_real_IXPE.py
```

## Data source

Stewart et al., Nature 656, 590 (2026)  
GitHub: https://github.com/rae-stewart/Polarimetric-Analysis-of-1E-1547.0-5408

## Honest statement for Zenodo / JOSS

Methodological cycle (EFT + likelihoods + public code): **closed**.  
Proof cycle (Δχ² > 9 in at least one pillar): **still open**.
